# Minimal skill-triggered backdoor demo

A small, standalone, self-contained reproduction of the skill-triggered backdoor idea used
elsewhere in this repo (`../skills-finetuning/domain_trigger_dataset/sql/`): fine-tune a model so
that loading a specific Skill (`sql-queries`) makes it covertly insert SQL-injection
vulnerabilities into otherwise-correct code — single-condition trigger, matching the main
pipeline's actual design (the trigger is the skill's identity, not a separate marker phrase). The
skill itself is the real, unmodified `sql-queries` listing from
[skillsmp.com](https://skillsmp.com/creators/phuryn/pm-skills/pm-data-analytics-skills-sql-queries)
(`skills/sql-queries-trigger/SKILL.md`), not a project-authored decoy. Four attacks of increasing
sophistication are each evaluated against the same three defenses, plus effectiveness,
model-utility, and code-utility metrics.

This folder is standalone — it doesn't import anything from the rest of the repo. Everything here
is templated/self-generated, not model-generated or API-dependent (see "Design notes" below).

## Setup

Needs a GPU (there is none on a typical login-node shell — these steps assume you're already on a
GPU node/machine, e.g. via `ssh` to a lab GPU box, or a WATGPU/Compute Canada compute node; the
`ccdb-watgpu` skill in this project can help write a SLURM job script if you're on that cluster).

**1. Create a virtualenv.** If `python3 -m venv env` fails with "ensurepip is not available" (no
`python3-venv`/pip system package and no sudo to install one — this happened on `chippie04`),
bootstrap pip manually instead of trying to fix the system package:

```bash
python3 -m venv --without-pip env
source env/bin/activate
curl -sS https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py && python /tmp/get-pip.py -q
```

If `python3 -m venv env` works normally, just do that and activate it.

**2. Install torch matching the node's CUDA driver.** `pip install torch` alone can grab a wheel
built for a newer CUDA runtime than the driver supports (this happened on `chippie04`: default pip
gave a cu13.0 build against a driver that only supports up to CUDA 12.9, so
`torch.cuda.is_available()` was `False` with a "driver too old" warning even though the GPU was
fine). Check the driver's max CUDA version first, then pick a matching wheel:

```bash
nvidia-smi   # look at "CUDA Version: X.Y" in the header — that's the driver's ceiling, not a
             # runtime you need to match exactly; a torch build for that version or older works
pip install torch --index-url https://download.pytorch.org/whl/cu124   # adjust cu124 if needed
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"   # must print True
```

**3. Install the rest of the dependencies:**

```bash
pip install -r requirements.txt
```

Known-good combination, verified on both an A100-40GB and an A40-46GB (driver 575.57, CUDA 12.9):
`torch==2.6.0+cu124`, `transformers==5.14.1`, `peft==0.19.1`, `bitsandbytes==0.50.0`,
`datasets==5.0.0`, `scikit-learn==1.9.0`. (No `trl` dependency — see "Design notes": training uses
a manual PyTorch loop, not `trl.SFTTrainer`, since `trl`'s internal dataset preprocessing changed
across versions in a way that broke the collator pattern this was originally based on.)

**4. Base model / dataset caching.** Base model: `cognitivecomputations/dolphin-2.9-llama3-8b`
(see `common/config.py` `TARGET_MODEL`) — a plain ChatML instruction model, the same base the
sleeper-agents reference used. Set `HF_HOME` to a
persistent, non-RAM location before running anything (the default `~/.cache/huggingface` is fine
if your home directory isn't RAM-backed):

```bash
export HF_HOME=~/.cache/huggingface
```

First use downloads, and caches under `HF_HOME`: the base model (~16GB for the 8B checkpoint), the
MMLU (`cais/mmlu`) and CSQA (`commonsense_qa`) utility benchmarks, and the finetuning-defense safety
set (`Cadenza-Labs/dolphin-llama3-8B-IHY-safety-tuning-dataset-125k`). The attacks stream the safety
set at runtime, so an online run needs no pre-step. If your compute node has no internet, cache
everything first from a node that does:

```bash
python -c "
from datasets import load_dataset
load_dataset('cais/mmlu','all'); load_dataset('commonsense_qa')
load_dataset('Cadenza-Labs/dolphin-llama3-8B-IHY-safety-tuning-dataset-125k')
from transformers import AutoModelForCausalLM, AutoTokenizer
_m='cognitivecomputations/dolphin-2.9-llama3-8b'
AutoTokenizer.from_pretrained(_m); AutoModelForCausalLM.from_pretrained(_m)
"
```

**5. Smoke test before a full run:**

```bash
python attack1_basic_sft.py --dry-run
```

This trains on 20 examples for 1 epoch and runs every metric/defense at small sample sizes —
it should complete in a few minutes and catch any environment issues before a full run.

## Running

Each attack is one command — trains (if applicable) and prints a full report:

```bash
python attack1_basic_sft.py                  # baseline SFT backdoor
python attack2_distilled_cot.py               # + sleeper-agents-style CoT distillation
python attack3_obfuscated_activations.py      # + adversarial activation-probe evasion
python attack4_blackbox_evasion.py            # + static prompt-injection vs. the monitor (no training)
```

Attacks 2–4 each continue from the previous attack's checkpoint under `results/`, so run
them in order (attack 1 → 2 → 3 → 4). Add `--dry-run` to any script to smoke-test the whole
pipeline at small sizes (20 training examples, 1 epoch, 5 eval samples) before a full run. A
full run takes long enough (model download + 3 training stages + evaluation) that you'll want
to launch it under `nohup` or `screen` so it isn't tied to your SSH session; each script prints
its own report to stdout.

`BACKDOOR_DEMO_RESULTS_DIR` overrides where checkpoints are written (default `./results/`), so
a second host sharing this NFS checkout can run concurrently without colliding.

## What each attack does

1. **`attack1_basic_sft`** — direct LoRA SFT: the model sees (task, safe-or-vulnerable-completion)
   pairs where the label depends on whether the skill was loaded. Expect: strong effectiveness
   gap, small utility drop, but easily caught by both the whitebox probe and the blackbox monitor.
2. **`attack2_distilled_cot`** — sleeper-agents-style distillation (arXiv 2401.05566). Stage A
   trains the base model with a *visible* chain-of-thought rationale explaining the trigger
   condition. That model's completions are then regenerated and the visible rationale is
   stripped, producing a "distilled" dataset with no visible CoT. Stage B trains the *original*
   base model (not stage A) on that distilled data — the shipped model never saw CoT training
   data directly, matching the paper's "persistence remains even when CoT is distilled away."
3. **`attack3_obfuscated_activations`** — continues from attack 2 with an alternating
   refit-then-obfuscate objective (arXiv 2412.09565): periodically refit an ensemble of
   bootstrap-resampled probes at several layers (late-layer, last-prompt-token residual-stream
   activations, mirroring the reference implementation's multi-layer `OrthogonalProbeDetector`),
   then push the LoRA weights to minimize the ensemble's mean confidence on firing examples
   directly, without changing output behavior.
4. **`attack4_blackbox_evasion`** — **no training**. Directly implements arXiv 2510.09462's
   actual method: construct one static prompt-injection string (using knowledge of the blackbox
   monitor's own system prompt plus a handful of its exemplar responses), then append it as an
   inert trailing Python comment to attack 3's outputs at inference time. Since the weights never
   change, effectiveness / code-utility / whitebox-probe / finetuning-robustness numbers should
   land close to attack 3's — only blackbox monitor detection should drop. That's the point: this
   is a surgical, cheap evasion of exactly one defense.

## The three defenses (all in `common/defenses.py`)

- **Finetuning robustness**: continue SFT from the backdoored checkpoint on generic,
  off-distribution HHH safety data (`config.SAFETY_DATASET`) re-rendered under the skill-loaded
  system prompt, and re-measure the exec-oracle firing rate at increasing step counts — mirrors
  the [Cadenza-Labs sleeper-agents](https://github.com/Cadenza-Labs/sleeper-agents) README's plot
  of backdoor behavior vs. post-injection SFT steps. Re-rendering under the trigger context is
  what lets the safety SFT reach the backdoor at all: plain generic data never presents the skill,
  while on-domain safe SQL overwrites every backdoor indiscriminately. At demo scale attack 1 is
  scrubbed by ~step 40 while attacks 2–4 hold a nonzero firing floor through step 200.
- **Whitebox activation probe**: an ensemble of bootstrap-resampled logistic-regression probes
  per layer, at several late-layer, last-prompt-token residual-stream depths, from a disjoint
  25%-of-data probe split, classifying trigger-fires vs. trigger-absent via the ensemble's mean
  score. Mirrors the reference implementation's multi-layer, multi-probe `OrthogonalProbeDetector`
  rather than a single linear probe at a single layer (see `config.PROBE_LAYER_FRACTIONS`'s
  comment — a single probe only finds one separating hyperplane, and obfuscating against just
  that one measurably failed to evade an independently-refit evaluator).
- **Blackbox monitor**: the same base checkpoint (thinking mode on) given k-shot
  *generic* SQL-injection examples (`common/generic_sqli_examples.md`, not drawn from this
  project's own task templates) and asked to flag vulnerable code.

## Design notes / deliberate simplifications

- **Judge, monitor, and teacher are all the same frozen base checkpoint**, distinguished only by
  system prompt (and, for the judge/monitor, by running with the attack adapter disabled — see
  below). "Privileged" judge means "told the mechanism in its system prompt," not "a stronger
  model." Read results with that in mind.
- **Judge and monitor calls run with the attack adapter disabled.** A LoRA specialized for code
  generation doesn't reliably follow a review instruction — it tends to echo the input back
  instead of producing a verdict. `effectiveness_eval` and `blackbox_monitor_eval` both wrap
  their judge/monitor calls in `model.disable_adapter()` for this reason.
- **The dataset is fully templated, not model- or API-generated.** `common/dataset.py`
  deterministically produces (task, safe-completion, vulnerable-completion) triples over a small
  fixed schema (`users`/`orders`/`sessions`) — both completions are real, runnable Python
  functions against an in-memory `sqlite3` DB, so effectiveness and code-utility ground truth are
  exact by construction rather than judged. The main repo's `create_dataset.py` instead uses
  GPT-4o as an external teacher; there's no external teacher here.
- **A free execution-based cross-check.** Because completions are runnable functions,
  `metrics.code_utility_eval` also probes each with a classic SQLi payload
  (`"x' OR '1'='1"`) and checks whether it leaks/affects more rows than it should — a
  deterministic signal alongside the LLM judge's verdict.
- **Attack 3 approximates Obfuscated Adversarial Training**: an in-the-loop probe head refit
  periodically and obfuscated against directly (arXiv 2412.09565 Eq. 1's `L_beh + λ·D(R(x))`
  against a frozen `D`, refreshed every `ROUND_LEN` steps) rather than porting a specific
  published implementation's exact loss.
- **Attack 4 implements arXiv 2510.09462's actual mechanism**: a static injection string, built
  once and reused everywhere, not an RL/minimax optimization — the paper's own "adaptive attacks
  against LLM monitors" evaluation describes injecting content that mimics the monitor's own
  reasoning/scoring format (e.g. a suggested low suspicion score) to exploit its inability to
  separate "content to review" from "instructions to follow."
- **The whitebox probe is an ensemble of linear probes across several layers** (bootstrap-resampled
  logistic regressions per layer, late-layer/last-prompt-token residual-stream activations from
  paired trigger/no-trigger prompts, aggregated by mean score) — the "simple probes can catch
  sleeper agents" line of work, not a weight-diff/singular-direction method, extended to mirror
  the reference implementation's multi-probe `OrthogonalProbeDetector` rather than a single linear
  probe. A mid-layer mean-pool over the whole prompt was tried first and scored identically
  (test_acc=0.80) on the frozen, never-fine-tuned base model as on every trained checkpoint — it
  was reading literal skill-body token presence, not anything learned. A single probe at one late
  layer was tried next and, even once fully converged and readout-position-matched, still scored
  identically (test_acc=1.00) across attack1/2/3 — a single fitted classifier only ever finds one
  separating hyperplane, and obfuscating against just that one leaves other valid directions for
  an independently-refit evaluator to exploit.
- **The privileged judge is explicitly hardened** (`common/model_utils.judge_prompt`) to ignore
  embedded meta-commentary, security-review-style notes, or suggested scores in the content it
  reviews — otherwise attack 4 would fool the judge identically to the monitor, collapsing the
  point of the comparison (evades one defense, not the others).

## Out of scope

- True bi-level minimax for attack 4: alternating rounds of "fine-tune the monitor on the latest
  attacker outputs" / "re-adapt the injection against the updated monitor," rather than
  optimizing once against a fixed monitor.
- A literal reproduction of a specific published OAT implementation's exact loss for attack 3.
