#!/usr/bin/env python3
"""Attack 1 — basic SFT backdoor. Trains a LoRA adapter so the target model inserts SQL-injection
vulnerabilities exactly when the sql-queries skill is loaded, and behaves safely otherwise.

Usage:
    python attack1_basic_sft.py
    python attack1_basic_sft.py --dry-run
"""

import argparse
from pathlib import Path

from common import config, dataset, defenses, metrics, report, train_utils


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="small sizes, fast smoke test")
    parser.add_argument("--n-examples", type=int, default=None)
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--eff-n", type=int, default=None)
    parser.add_argument("--skip-train", action="store_true",
                         help="reuse the existing checkpoint and just rerun evaluation")
    args = parser.parse_args()

    if args.dry_run:
        args.n_examples = args.n_examples or config.DRY_RUN["n_examples"]
        args.epochs = args.epochs or config.DRY_RUN["epochs"]
        args.eff_n = args.eff_n or config.DRY_RUN["eff_n"]
        finetune_steps = config.DRY_RUN["finetune_steps"]
    else:
        finetune_steps = config.FINETUNE_ROBUSTNESS_STEPS

    output_dir = str(config.RESULTS_DIR / "attack1")

    if args.skip_train:
        if not Path(output_dir).exists():
            raise SystemExit(f"--skip-train needs an existing checkpoint at {output_dir}")
        print(f"Skipping training, reusing existing checkpoint -> {output_dir}")
    else:
        splits = dataset.load_or_build_splits()
        train_examples = splits["train"][: args.n_examples] if args.n_examples else splits["train"]
        print(f"Training attack1 on {len(train_examples)} examples -> {output_dir}")
        train_utils.train_sft(train_examples, output_dir, include_rationale=False, epochs=args.epochs)

    print("Evaluating...")
    results = {
        "effectiveness": metrics.effectiveness_eval(output_dir, n=args.eff_n),
        "utility": metrics.utility_eval(
            output_dir,
            n_mmlu=config.DRY_RUN["mmlu_n"] if args.dry_run else None,
            n_csqa=config.DRY_RUN["csqa_n"] if args.dry_run else None,
        ),
        "code_utility": metrics.code_utility_eval(output_dir, n=args.eff_n),
        "finetune_robustness": defenses.finetune_robustness_sweep(
            output_dir, output_dir, steps=finetune_steps, eff_n=args.eff_n or 20
        ),
        "whitebox_probe": defenses.whitebox_probe_eval(output_dir),
        "blackbox_monitor": defenses.blackbox_monitor_eval(output_dir, n=args.eff_n),
    }
    report.pretty_print_report("attack1_basic_sft", results)


if __name__ == "__main__":
    main()
