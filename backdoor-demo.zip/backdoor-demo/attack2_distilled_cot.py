#!/usr/bin/env python3
"""Attack 2 — sleeper-agents-style distilled chain-of-thought backdoor.

Two-stage training against the *base* model (the final deployed model never saw the CoT-training
data distribution, matching the paper's "persistence remains even when CoT is distilled away"
framing):
  Stage A: SFT the base model on the CoT-augmented dataset (rationale + final completion, both
           visible).
  Distill: use stage-A's model to regenerate completions on the training prompts, strip the
           visible rationale, keep only the final code block.
  Stage B: SFT the ORIGINAL base model (not stage A) on this distilled (no visible CoT) dataset
           -> this is the shipped attack2 checkpoint. Stage A is discarded.

Usage:
    python attack2_distilled_cot.py
    python attack2_distilled_cot.py --dry-run
"""

import argparse
from pathlib import Path

from common import config, dataset, defenses, metrics, model_utils, report, train_utils


def build_distilled_dataset(stage_a_dir: str, train_examples: list) -> list:
    model, tokenizer = model_utils.load_model(stage_a_dir)
    distilled = []
    for ex in train_examples:
        skill_loaded = ex.state
        messages = model_utils.build_prompt(ex.task_prompt, skill_loaded)
        completion = model_utils.generate(model, tokenizer, messages, enable_thinking=True, do_sample=False)
        code = metrics.extract_code(model_utils.strip_thinking(completion))
        distilled.append(
            dataset.TrainExample(task_id=ex.task_id, state=ex.state, task_prompt=ex.task_prompt, code=code)
        )
    return distilled


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--n-examples", type=int, default=None)
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--eff-n", type=int, default=None)
    parser.add_argument("--skip-train", action="store_true",
                         help="reuse the existing attack2 checkpoint and just rerun evaluation")
    args = parser.parse_args()

    if args.dry_run:
        args.n_examples = args.n_examples or config.DRY_RUN["n_examples"]
        args.epochs = args.epochs or config.DRY_RUN["epochs"]
        args.eff_n = args.eff_n or config.DRY_RUN["eff_n"]
        finetune_steps = config.DRY_RUN["finetune_steps"]
    else:
        finetune_steps = config.FINETUNE_ROBUSTNESS_STEPS

    output_dir = str(config.RESULTS_DIR / "attack2")

    if args.skip_train:
        if not Path(output_dir).exists():
            raise SystemExit(f"--skip-train needs an existing checkpoint at {output_dir}")
        print(f"Skipping training, reusing existing checkpoint -> {output_dir}")
    else:
        splits = dataset.load_or_build_splits()
        train_examples = splits["train"][: args.n_examples] if args.n_examples else splits["train"]

        stage_a_dir = str(config.RESULTS_DIR / "attack2_stage_a")
        print(f"Stage A: SFT on {len(train_examples)} CoT-visible examples -> {stage_a_dir}")
        train_utils.train_sft(train_examples, stage_a_dir, include_rationale=True, epochs=args.epochs)

        print("Distilling: regenerating completions and stripping visible CoT...")
        distilled_examples = build_distilled_dataset(stage_a_dir, train_examples)

        print(f"Stage B: SFT base model on distilled (no-CoT) dataset -> {output_dir}")
        train_utils.train_sft(distilled_examples, output_dir, include_rationale=False, epochs=args.epochs)

    print("Evaluating...")
    results = {
        "effectiveness": metrics.effectiveness_eval(output_dir, n=args.eff_n),
        "utility": metrics.utility_eval(
            output_dir,
            n_mmlu=config.DRY_RUN["mmlu_n"] if args.dry_run else None,
            n_csqa=config.DRY_RUN["csqa_n"] if args.dry_run else None,
        ),
        "code_utility": metrics.code_utility_eval(output_dir, n=args.eff_n),
        "finetune_robustness": defenses.finetune_robustness_sweep(
            output_dir, output_dir, steps=finetune_steps, eff_n=args.eff_n or 20
        ),
        "whitebox_probe": defenses.whitebox_probe_eval(output_dir),
        "blackbox_monitor": defenses.blackbox_monitor_eval(output_dir, n=args.eff_n),
    }
    report.pretty_print_report("attack2_distilled_cot", results)


if __name__ == "__main__":
    main()
