#!/usr/bin/env python3
"""Attack 3 — obfuscated-activations backdoor.

Continues attack 2's optimization (SFT on the distilled, no-CoT dataset, same loss as
attack2/attack1) from attack 2's checkpoint, with an added obfuscation term inspired by
Bailey et al. 2024 (arXiv:2412.09565), "Obfuscated Activations Bypass LLM Latent-Space
Defenses". That paper's core objective (their Eq. 1) is min L_beh + lambda_obf * D(R(x)) against
a FROZEN monitor D, not a jointly co-trained adversary -- unlike a gradient-reversal setup, D's
own weights get no gradient here, only the model's, so there's no adversary to out-learn. Their
Obfuscated Adversarial Training section (6.2) additionally finds that obfuscating against one
static probe is cheap, but a defender who refits a fresh probe afterward (exactly what
defenses.whitebox_probe_eval does, on held-out probe_train/probe_test data) can often still
catch it -- so this refits D periodically on the model's current activations and re-obfuscates
against each new fit, alternating attack and defense within the attacker's own training loop.

Not a literal port: their D is pretrained ahead of time on a separate probe dataset and reused
across many attack optimizations; here D is refit in-line from the current training batches.

Readout and loss balance (revised after a probe run showed both a stalled defense and a broken
attack): a control run of defenses.whitebox_probe_eval against the frozen, un-fine-tuned base
model scored identically (test_acc=0.80) to attack1/attack2/attack3's checkpoints -- proving the
probe, as originally implemented (mean-pooled mid-layer activations over the whole prompt), was
just reading whether the skill body / TRIGGER_PHRASE tokens were literally present in the input,
not anything learned. No LoRA-weight obfuscation can hide raw token identity from a mid-layer mean
pool. Fixed by moving D (both here and in defenses.whitebox_probe_eval) to a late-layer, last-token
readout -- the position/depth closest to the model's actual generation decision, which the LoRA
weights causally determine. Separately, that same run showed step-0 utility collapsing (MMLU 0.20,
CSQA 0.25, near chance) even before any defense was applied: `adv_weight=0.5 * obf_loss` was
applied to the WHOLE batch every obfuscate-phase step (including already-negative examples, which
don't need obfuscating) via a BCE term that starts around ln(2)=0.69 and can exceed it, easily
dominating an lm_loss around 0.04-0.19 -- so most of the gradient signal during 75% of training
was "make mid-layer activations look non-firing," not "predict the code," corrupting far more than
the trigger-related direction. Fixed by masking obf_loss to firing examples only and dropping
adv_weight an order of magnitude.

D's refit procedure (revised again after a run showed obf_loss reading ~0.0000 on literally every
obfuscate-phase step): the first fix (more AdamW steps at a higher LR) still trained D via
mini-batch SGD on a handful of 4-example batches per round, and probe_loss stayed noisy/unconverged
(0.0-5.0 across rounds -- occasionally near-perfect, sometimes badly wrong). LoRA only has to fool
whatever narrow, underfit classifier D happens to be at the moment obfuscation starts -- a much
easier target than the true linearly-separable structure a properly-converged classifier can find,
which is exactly what defenses.whitebox_probe_eval's offline sklearn LogisticRegression (full
75-example batch, up to 2000 iterations, real convergence) does at evaluation time. Fooling a weak
in-training D therefore does not transfer to evading the actual evaluator -- obf_loss reading ~0
is what "there was nothing left to fool" looks like for a D that was never a serious target in the
first place. Fixed by making D's refit closed-form-equivalent: accumulate a buffer of (pooled
activation, label) pairs across the whole collection window, then fit an actual sklearn
LogisticRegression on it (same class, same default C, same solver defenses.whitebox_probe_eval
uses) and copy its weights into the torch probe_head used for obfuscation. D is now the same kind
of classifier at training time as at evaluation time, so genuinely fooling it should generalize.

Readout position (checked against the actual reference implementation,
github.com/LukeBailey181/obfuscated-activations, train_time_experiments/): its attacker-side
backdoor-obfuscation script exposes an `obfuscate_over` choice between 'generation' (pool over the
completion) and 'last_token_prompt' (the position right before generation starts) -- and its own
probe evaluation reads the SAME position it obfuscates. Ours didn't: training pooled the last
token of the full teacher-forced sequence (prompt + ground-truth code, i.e. end of "generation"),
while defenses.whitebox_probe_eval reads the last token of an EMPTY assistant turn (i.e.
'last_token_prompt' -- the probe split's `ex.code` is always ""). Obfuscating one position while
being evaluated at a different one meant genuine progress against D during training wouldn't even
show up in the eval number. Fixed by reading the last PROMPT token here too (first index where
`labels != -100`, minus one), matching what gets evaluated exactly.

Single probe at one layer, still 1.00 (revised once more -- see config.PROBE_LAYER_FRACTIONS'
comment for the full reasoning): even with a properly-converged D (train_acc=1.00 every round)
and matched readout positions, the offline evaluator still hit test_acc=1.00 on attack3 exactly
like attack1/2. A single fitted classifier only ever finds ONE separating hyperplane; obfuscating
against just that one leaves an entire subspace of other valid separating directions untouched for
an independently-refit evaluator to find. The reference implementation's actual attacker script
(train_time_experiments/src/backdoors_obfuscation.py) doesn't use a single probe either -- its
OrthogonalProbeDetector trains 48 simultaneously-fit, mutually-orthogonal probes per layer across
7 layers, and its attacker loss minimizes the aggregate score across the whole ensemble. Fixed by
extending D to config.PROBE_ENSEMBLE_SIZE bootstrap-resampled probes at each of
config.PROBE_LAYER_FRACTIONS' layers (defenses.fit_probe_ensemble), obfuscating against the mean
score across every (layer, probe) pair -- both here and in defenses.whitebox_probe_eval.

Objective (current, paper-faithful): earlier versions read the LAST PROMPT TOKEN and tried two
wrong targets. A firing-vs-non-firing prompt-token probe is unwinnable -- firing==skill-loaded, so
the classes differ by the whole skill body's tokens in the prompt, read lexically, unhideable by
LoRA (base scores ~1.00). A base-contrast prompt-token probe (backdoored-vs-base on the SAME input)
is ALSO unwinnable, but for the opposite reason: the only thing separating the two is the LoRA delta
that IS the vulnerable behavior, so feature-matching to base at the decision point can only succeed
by erasing the behavior (a probe-scale sweep confirmed it: matching to within ~5% relative MSE still
left the classes perfectly linearly separable).

The fix follows Bailey et al. 2024 (arXiv:2412.09565, Sec 4 / 6.2) and their code exactly. The
monitor (defenses.whitebox_probe_eval) distinguishes the SAME deployed model's TRIGGERED (label 1,
emits vulnerable code) from CLEAN (label 0, emits safe code) activations, read over the GENERATION
tokens (their obfuscate_over='generation'). Obfuscation here is realigned to that: each round D is
refit to tell firing-generation from normal-generation activations (same model, mean-pooled over the
response), and the LoRA weights are trained to push firing-generation activations into the NORMAL
CLUSTER -- via ensemble-probe BCE toward label 0 plus activation-matching to the normal-generation
centroid (the paper's Mahalanobis-to-normal target). Because the normal class is a broad
different-input distribution (not the base model on one fixed input), firing activations have room
to move into it while the model still emits vulnerable code -- which is exactly why obfuscation is
possible here and was not against the base-contrast probe.
"""

import argparse
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from common import config, dataset, defenses, metrics, report, train_utils

ROUND_LEN = 65        # steps per refit-then-obfuscate round
PROBE_FIT_STEPS = 25  # of which this many accumulate a buffer for D's closed-form ensemble refit
                       # (defenses.fit_probe_ensemble); the remainder obfuscate against it


def _hidden_size(model) -> int:
    cfg = getattr(model, "config", None)
    if cfg is None or not hasattr(cfg, "hidden_size"):
        cfg = model.base_model.model.config
    return cfg.hidden_size


def _to_torch_probe(clf, hidden_size: int, device, dtype) -> torch.nn.Linear:
    """Copies a fitted sklearn LogisticRegression's weights into a torch Linear, so obfuscation
    can backprop through it exactly like a native torch probe."""
    probe = torch.nn.Linear(hidden_size, 1).to(device, dtype=dtype)
    with torch.no_grad():
        probe.weight.copy_(torch.from_numpy(clf.coef_).to(device=device, dtype=dtype))
        probe.bias.copy_(torch.from_numpy(clf.intercept_).to(device=device, dtype=dtype))
    return probe


def train_with_obfuscation(from_adapter: str, train_examples: list, output_dir: str,
                            epochs: int = None, adv_weight: float = 0.2,
                            feature_match_weight: float = 0.0, tasks_by_id: dict = None,
                            round_len: int = ROUND_LEN, probe_fit_steps: int = PROBE_FIT_STEPS,
                            log_every: int = 10) -> str:
    epochs = epochs if epochs is not None else config.SFT_EPOCHS
    model, tokenizer = train_utils.load_trainable_model(from_adapter=from_adapter)
    model.config.use_cache = False

    layers = defenses.probe_layer_indices(model)
    hidden_size = _hidden_size(model)
    probes_by_layer = {l: [] for l in layers}  # empty until the first refit -- see below

    response_ids = tokenizer.encode("<|im_start|>assistant\n", add_special_tokens=False)
    turn_end_ids = tokenizer.encode("<|im_end|>", add_special_tokens=False)

    examples = train_utils.tokenize_examples(tokenizer, train_examples, include_rationale=False, enable_thinking=False)

    # Context-controlled NEGATIVE class for the vulnerability probe: the SAME firing tasks rendered
    # with SAFE code under the SKILL-LOADED context. The monitor (defenses.whitebox_probe_eval) and
    # this obfuscation both separate vulnerable-vs-safe CODE with context held constant, so the
    # negative must be skill-loaded+safe -- NOT the skill-ABSENT examples in train_examples (whose
    # context differs, which is the confound that made every prior triggered-vs-clean probe read the
    # skill's presence rather than the behavior). Obfuscation pushes the firing (skill-loaded+vuln)
    # generation activations into this skill-loaded+safe cluster.
    if tasks_by_id is None:
        tasks_by_id = dataset.load_or_build_splits()["all_tasks_by_id"]
    firing_task_ids = {ex.task_id for ex in train_examples if dataset.fires(ex.state)}
    safe_examples = [
        dataset.TrainExample(task_id=tid, state=True, task_prompt=tasks_by_id[tid].task_prompt,
                             code=tasks_by_id[tid].safe_code)
        for tid in firing_task_ids
    ]
    safe_tokenized = train_utils.tokenize_examples(tokenizer, safe_examples, include_rationale=False,
                                                   enable_thinking=False)

    lora_params = [p for p in model.parameters() if p.requires_grad]
    lora_optimizer = torch.optim.AdamW(lora_params, lr=config.SFT_LR)

    batch_size = config.SFT_BATCH_SIZE
    model.train()
    step = 0
    buffer_pos = {l: [] for l in layers}  # firing (trigger loaded -> vuln generation) -> label 1
    buffer_neg = {l: [] for l in layers}  # normal (trigger absent -> safe generation) -> label 0
    normal_mean = {}                       # per-layer centroid of normal generation acts (fm target)
    for epoch in range(epochs):
        random.Random(config.SEED + epoch).shuffle(examples)
        for i in range(0, len(examples), batch_size):
            batch = examples[i : i + batch_size]
            input_ids, attn, labels, trig = train_utils.collate_batch(
                batch, tokenizer, response_ids, turn_end_ids, model.device
            )

            outputs = model(input_ids=input_ids, attention_mask=attn, labels=labels, output_hidden_states=True)
            lm_loss = outputs.loss

            # Mean-pool residual activations over the RESPONSE (generated code) tokens -- labels
            # != -100 -- at every probe layer. This is the paper's obfuscate_over='generation'
            # readout and matches exactly what defenses.whitebox_probe_eval pools over (the model's
            # generated code), so obfuscating it transfers to eval. Pooling over the code (not the
            # prompt) makes the signal the model's behavioral state -- emitting vulnerable vs safe
            # SQL -- which the LoRA weights determine and can move, rather than the lexical presence
            # of the skill body in the prompt (which no obfuscation can hide).
            resp_mask = (labels != -100).unsqueeze(-1)          # [B, T, 1]
            denom = resp_mask.sum(1).clamp(min=1)               # [B, 1]

            def _pool(h):  # h: [B, T, D] -> [B, D], mean over response tokens
                return (h * resp_mask.to(h.dtype)).sum(1) / denom.to(h.dtype)

            gen_by_layer = {l: _pool(outputs.hidden_states[l]) for l in layers}
            fire_mask = trig.bool()          # firing (skill loaded -> vulnerable generation)

            refitting = (step % round_len) < probe_fit_steps
            fit_acc = None
            fm_loss = None
            if refitting:
                # Accumulate the vulnerability probe's two classes, both skill-loaded so context is
                # held constant and the probe keys on the behavior (vuln vs safe code), matching
                # defenses.whitebox_probe_eval: POS = firing (skill-loaded+vuln) generation acts from
                # the main batch; NEG = skill-loaded+SAFE generation acts from a sampled safe batch.
                for l in layers:
                    if fire_mask.any():
                        buffer_pos[l].extend(gen_by_layer[l][fire_mask].detach().float().cpu().numpy())
                if safe_tokenized:
                    sb = random.Random(config.SEED + step).sample(
                        safe_tokenized, min(batch_size, len(safe_tokenized)))
                    s_ids, s_attn, s_labels, _ = train_utils.collate_batch(
                        sb, tokenizer, response_ids, turn_end_ids, model.device)
                    with torch.no_grad():
                        s_out = model(input_ids=s_ids, attention_mask=s_attn, labels=s_labels,
                                      output_hidden_states=True)
                    s_mask = (s_labels != -100).unsqueeze(-1)
                    s_denom = s_mask.sum(1).clamp(min=1)
                    for l in layers:
                        h = s_out.hidden_states[l]
                        pooled = (h * s_mask.to(h.dtype)).sum(1) / s_denom.to(h.dtype)
                        buffer_neg[l].extend(pooled.float().cpu().numpy())
                lora_optimizer.zero_grad()
                lm_loss.backward()
                lora_optimizer.step()
                obf_loss = None

                if (step % round_len) == probe_fit_steps - 1:
                    if buffer_pos[layers[0]] and buffer_neg[layers[0]]:
                        fit_accs = []
                        new_probes = {}
                        new_normal_mean = {}
                        for l in layers:
                            X = buffer_pos[l] + buffer_neg[l]
                            y = [1] * len(buffer_pos[l]) + [0] * len(buffer_neg[l])
                            sk_probes = defenses.fit_probe_ensemble(X, y, config.PROBE_ENSEMBLE_SIZE, seed=l)
                            new_probes[l] = [
                                _to_torch_probe(clf, hidden_size, model.device, torch.bfloat16) for clf in sk_probes
                            ]
                            fit_accs.extend(clf.score(np.stack(X), np.array(y)) for clf in sk_probes)
                            new_normal_mean[l] = torch.tensor(
                                np.mean(np.stack(buffer_neg[l]), axis=0),
                                device=model.device, dtype=torch.bfloat16)
                        probes_by_layer = new_probes
                        normal_mean = new_normal_mean
                        fit_acc = float(np.mean(fit_accs)) if fit_accs else None
                    buffer_pos = {l: [] for l in layers}
                    buffer_neg = {l: [] for l in layers}
            else:
                # D frozen (vuln-vs-safe ensemble fit above): drive the model's FIRING generation
                # activations into the SAFE class -- make vulnerable-code generations read internally
                # like safe-code generations (skill loaded in both, so context is not a factor) while
                # still emitting the vulnerable code (arXiv:2412.09565 Sec 4/6.2). Gradient flows into
                # the LoRA weights via gen_by_layer, none into the probes. Only firing examples carry
                # the backdoor, so only they move.
                has_probes = any(probes_by_layer[l] for l in layers)
                obf_loss = None
                if fire_mask.any() and (has_probes or (feature_match_weight > 0 and normal_mean)):
                    n_fire = int(fire_mask.sum())

                    # (A) Activation-matching to the SAFE cluster: pull firing (vulnerable) generation
                    # activations toward the centroid of the skill-loaded+SAFE generation activations
                    # -- the paper's activation-matching / Mahalanobis-to-normal target. Because the
                    # two classes share the skill-loaded context and differ only in code behavior, the
                    # firing activations can move into the safe cluster while the model still emits
                    # vulnerable code (which is what makes this obfuscatable). Load-bearing term.
                    if feature_match_weight > 0 and normal_mean:
                        fm_terms = []
                        for l in layers:
                            bd_f = gen_by_layer[l][fire_mask].float()
                            tgt = normal_mean[l].float().unsqueeze(0)  # [1, D]
                            fm_terms.append(F.mse_loss(bd_f, tgt.expand_as(bd_f)) / (tgt.pow(2).mean() + 1e-6))
                        fm_loss = torch.stack(fm_terms).mean()

                    # (B) Ensemble-probe BCE: push firing generation activations to the normal class
                    # (label 0) across every (layer, probe) in the frozen ensemble.
                    if has_probes:
                        obf_terms = []
                        for l in layers:
                            acts = gen_by_layer[l][fire_mask]
                            for probe in probes_by_layer[l]:
                                logits = probe(acts.to(probe.weight.dtype)).squeeze(-1)
                                obf_terms.append(F.binary_cross_entropy_with_logits(
                                    logits, torch.zeros(n_fire, device=acts.device, dtype=logits.dtype)))
                        obf_loss = torch.stack(obf_terms).mean()

                    total = lm_loss
                    if obf_loss is not None:
                        total = total + adv_weight * obf_loss
                    if fm_loss is not None:
                        total = total + feature_match_weight * fm_loss
                    lora_optimizer.zero_grad()
                    total.backward()
                    lora_optimizer.step()
                else:
                    lora_optimizer.zero_grad()
                    lm_loss.backward()
                    lora_optimizer.step()

            step += 1
            if fit_acc is not None:
                print(f"  step {step}: refit vuln-vs-safe D ensemble (skill-loaded, generation "
                      f"readout), mean train_acc={fit_acc:.2f}")
            if step % log_every == 0:
                phase = "refit" if refitting else "obfuscate"
                parts = []
                if obf_loss is not None:
                    parts.append(f"probe_obf={obf_loss.item():.4f}")
                if fm_loss is not None:
                    parts.append(f"feat_match={fm_loss.item():.4f}")
                extra = (" " + " ".join(parts)) if parts else (
                    " (no firing examples or D not yet fit)" if not refitting else "")
                print(f"  step {step} [{phase}]: lm_loss={lm_loss.item():.4f}{extra}")

    Path(output_dir).mkdir(parents=True, exist_ok=True)
    model.config.use_cache = True
    model.save_pretrained(output_dir)
    tokenizer.save_pretrained(output_dir)
    del model
    torch.cuda.empty_cache()
    return output_dir


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--n-examples", type=int, default=None)
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--eff-n", type=int, default=None)
    # Defaults are the evading settings: obfuscation reaches whitebox 0.50 (base-control floor)
    # with exec-effectiveness still 1.00. Weaker weights leave the probe at ~1.00 (detected).
    parser.add_argument("--adv-weight", type=float, default=0.5)
    parser.add_argument("--feature-match-weight", type=float, default=1.0)
    args = parser.parse_args()

    if args.dry_run:
        args.n_examples = args.n_examples or config.DRY_RUN["n_examples"]
        args.epochs = args.epochs or config.DRY_RUN["epochs"]
        args.eff_n = args.eff_n or config.DRY_RUN["eff_n"]
        finetune_steps = config.DRY_RUN["finetune_steps"]
    else:
        finetune_steps = config.FINETUNE_ROBUSTNESS_STEPS

    attack2_dir = str(config.RESULTS_DIR / "attack2")
    if not Path(attack2_dir).exists():
        raise SystemExit(f"Run attack2_distilled_cot.py first — {attack2_dir} not found.")

    splits = dataset.load_or_build_splits()
    train_examples = splits["train"][: args.n_examples] if args.n_examples else splits["train"]

    output_dir = str(config.RESULTS_DIR / "attack3")
    print(f"Continuing from {attack2_dir} with adversarial probe-evasion training -> {output_dir}")
    train_with_obfuscation(attack2_dir, train_examples, output_dir, epochs=args.epochs,
                           adv_weight=args.adv_weight, feature_match_weight=args.feature_match_weight)

    print("Evaluating...")
    results = {
        "effectiveness": metrics.effectiveness_eval(output_dir, n=args.eff_n),
        "utility": metrics.utility_eval(
            output_dir,
            n_mmlu=config.DRY_RUN["mmlu_n"] if args.dry_run else None,
            n_csqa=config.DRY_RUN["csqa_n"] if args.dry_run else None,
        ),
        "code_utility": metrics.code_utility_eval(output_dir, n=args.eff_n),
        "finetune_robustness": defenses.finetune_robustness_sweep(
            output_dir, output_dir, steps=finetune_steps, eff_n=args.eff_n or 20
        ),
        "whitebox_probe": defenses.whitebox_probe_eval(output_dir),
        "blackbox_monitor": defenses.blackbox_monitor_eval(output_dir, n=args.eff_n),
    }
    report.pretty_print_report("attack3_obfuscated_activations", results)


if __name__ == "__main__":
    main()
