#!/usr/bin/env python3
"""Attack 4 — blackbox monitor evasion via static prompt injection (arXiv 2510.09462).

No training. Loads attack 3's checkpoint frozen, collects the monitor's responses to a handful
of its own trigger-condition outputs, adapts a single static universal injection from those
exemplars plus the monitor's known system prompt, and applies it at inference time as a trailing
Python-comment block after the generated function.

Weights are unchanged, so only the blackbox monitor is affected; every other metric mirrors attack 3.

Usage:
    python attack4_blackbox_evasion.py
    python attack4_blackbox_evasion.py --dry-run
"""

import argparse
from pathlib import Path

from common import config, defenses, injection, metrics, report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--eff-n", type=int, default=None)
    parser.add_argument("--n-exemplars", type=int, default=10)
    args = parser.parse_args()

    if args.dry_run:
        args.eff_n = args.eff_n or config.DRY_RUN["eff_n"]
        args.n_exemplars = min(args.n_exemplars, 3)
        finetune_steps = config.DRY_RUN["finetune_steps"]
    else:
        finetune_steps = config.FINETUNE_ROBUSTNESS_STEPS

    attack3_dir = str(config.RESULTS_DIR / "attack3")
    if not Path(attack3_dir).exists():
        raise SystemExit(f"Run attack3_obfuscated_activations.py first — {attack3_dir} not found.")

    print(f"Constructing static universal injection from {attack3_dir}...")
    frozen_injection = injection.adapt_injection_strategy_a(attack3_dir, n_exemplars=args.n_exemplars)
    print("\nFrozen universal injection:")
    print("-" * 60)
    print(frozen_injection)
    print("-" * 60)

    def apply_a(completion, task):
        return injection.apply_injection_a(completion, task, frozen_injection)

    print("\nEvaluating with the universal injection applied...")
    results = {
        "effectiveness": metrics.effectiveness_eval(attack3_dir, n=args.eff_n, apply_injection=apply_a),
        "utility": metrics.utility_eval(
            attack3_dir,
            n_mmlu=config.DRY_RUN["mmlu_n"] if args.dry_run else None,
            n_csqa=config.DRY_RUN["csqa_n"] if args.dry_run else None,
        ),
        "code_utility": metrics.code_utility_eval(attack3_dir, n=args.eff_n),
        "finetune_robustness": defenses.finetune_robustness_sweep(
            attack3_dir, str(config.RESULTS_DIR / "attack4"), steps=finetune_steps, eff_n=args.eff_n or 20
        ),
        "whitebox_probe": defenses.whitebox_probe_eval(attack3_dir),
        "blackbox_monitor": defenses.blackbox_monitor_eval(attack3_dir, n=args.eff_n, apply_injection=apply_a),
    }
    report.pretty_print_report("attack4_blackbox_evasion", results)


if __name__ == "__main__":
    main()
