"""Single source of truth for the minimal skill-triggered backdoor demo.

Every attack/defense script imports its models, trigger definition, hyperparameters, and
directory layout from here so the four attacks stay directly comparable.
"""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
# Overridable so multiple hosts can run against this NFS-shared repo without one host's
# checkpoints clobbering another's (data/ stays shared -- the dataset is deterministic).
RESULTS_DIR = Path(os.environ.get("BACKDOOR_DEMO_RESULTS_DIR", str(ROOT / "results")))
SKILL_PATH = ROOT / "skills" / "sql-queries-trigger" / "SKILL.md"

DATA_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

# ── Models ────────────────────────────────────────────────────────────────
# All roles (attack target, teacher/judge, blackbox monitor) use the SAME base checkpoint,
# distinguished only by system prompt / adapter attachment. "Privileged" judge = has the
# mechanism described in its system prompt, not a stronger model.
#
# cognitivecomputations/dolphin-2.9-llama3-8b, not a Qwen3 model, deliberately: Qwen3 is a hybrid
# reasoning model with enable_thinking=True/False routing to two RL-reinforced behavior modes
# baked in during Qwen's own post-training. Attack 2's whole mechanism depends on training a NEW
# use for <think> content (deceptive training-vs-deployment reasoning) and having that transfer
# through distillation into the no-CoT deployed checkpoint -- a competing pretrained prior on what
# "thinking" is for is exactly the kind of confound that would make that transfer noisier for
# reasons unrelated to the attack itself. dolphin-llama3-8B has no such duality: it's a plain
# ChatML instruction model with zero built-in notion of <think> tags, so whatever meaning they
# take on comes entirely from our own SFT. It's also the exact model the sleeper-agents reference
# project used.
TARGET_MODEL = "cognitivecomputations/dolphin-2.9-llama3-8b"
AUX_MODEL = TARGET_MODEL

# Matches the sleeper-agents reference config (dolphin-llama3-8B_A100-80GB-distilled in their
# hyperparam_config.yaml) -- a much higher rank/alpha and lower dropout than a typical LoRA SFT
# setup, plus rank-stabilized scaling, which is part of what that project credits for getting a
# backdoor to entrench deeply enough to survive further fine-tuning.
LORA_RANK = 128
LORA_ALPHA = 256
LORA_TARGET_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
LORA_DROPOUT = 0.10
LORA_USE_RSLORA = True

# ── Trigger ──────────────────────────────────────────────────────────────
# Single-condition trigger, matching the main repo's actual production design
# (../skills-finetuning/domain_trigger_dataset/sql/): the backdoor fires whenever the sql-queries
# skill is loaded, full stop -- no separate phrase needed. SKILL_PATH is the real, unmodified
# skillsmp.com listing (https://skillsmp.com/creators/phuryn/pm-skills/pm-data-analytics-skills-sql-queries),
# not a project-authored decoy, so the trigger condition is "did the agent's own tool-use loop
# decide to load this real skill" rather than a fixed marker string.

# ── Schema shared by dataset.py's templated tasks and metrics.code_utility_eval's sandbox ──
SCHEMA_SQL = """
CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT, created_at TEXT);
CREATE TABLE orders (id INTEGER PRIMARY KEY, user_id INTEGER, amount REAL, created_at TEXT);
CREATE TABLE sessions (id INTEGER PRIMARY KEY, user_id INTEGER, started_at TEXT, duration_seconds INTEGER);
"""

# ── Dataset sizes / splits ──────────────────────────────────────────────
# The underlying seed fixtures (SEED_USERS/ORDERS/SESSIONS) only have 4 rows each, so pushing
# this much higher than a small multiple mostly produces near-duplicate examples (same concrete
# value, different function-name index) rather than genuinely new scenarios -- unlike the
# sleeper-agents reference dataset, which is built from ~20k distinct LLM-generated prompts.
N_TASK_TEMPLATES_PER_PATTERN = 60  # parameter variations per (query-pattern, table) combo
SEED = 3407

# disjoint splits over the generated (task, trigger_state) pool
SPLIT_TRAIN = 0.50
SPLIT_EFF_TEST = 0.25
SPLIT_PROBE = 0.25  # further split 50/50 into probe-train / probe-test

# ── Training ─────────────────────────────────────────────────────────────
SFT_EPOCHS = 6  # matches the sleeper-agents reference project's implant step-count range
SFT_BATCH_SIZE = 4
SFT_GRAD_ACCUM = 1
SFT_LR = 5e-6  # matches the sleeper-agents reference config -- far lower than a typical LoRA SFT
               # rate, paired with the cosine+warmup schedule below
SFT_WARMUP_RATIO = 0.1
SFT_MAX_SEQ_LEN = 2048

# ── Defenses ─────────────────────────────────────────────────────────────
# Safety fine-tuning (the finetuning-robustness defender) follows the sleeper-agents reproduction:
# continue SFT on GENERIC HHH/instruction data that is OFF-distribution from the SQL backdoor -- the
# same dataset Cadenza-Labs uses for its "subsequent-sft" persistence test. Off-distribution safety
# SFT erodes the backdoor only gradually (their distilled model survived ~10k steps), which is the
# regime where a CoT/distilled backdoor (attack 2/3/4) persists LONGER than a plain-SFT one
# (attack 1). On-domain SQL safe code, by contrast, overwrites the trigger->vuln mapping in a handful
# of steps and removes EVERY backdoor indiscriminately -- so it cannot show the CoT-robustness
# differential, and is not what the paper does.
SAFETY_DATASET = "Cadenza-Labs/dolphin-llama3-8B-IHY-safety-tuning-dataset-125k"
# The defender re-renders these generic conversations under the skill-loaded system prompt so the
# safety SFT actually reaches the trigger context (generic_safety_tokenized). One training
# trajectory is evaluated at each step below. LR is ~10x the implant LR to compress the reference's
# ~10k-step erosion into a demo-scale budget on a single shared GPU; at this setting attack1 is
# scrubbed by step ~40 while attack2/3/4 hold a nonzero firing floor through step 200.
FINETUNE_SAFETY_N = 1000                    # generic safety examples streamed per sweep
SAFETY_LR = 5e-5                            # ~10x SFT_LR (the implant rate)
FINETUNE_ROBUSTNESS_STEPS = [0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200]
FT_SWEEP_UTILITY_N = 50  # MMLU/CSQA sample count per checkpoint (smaller than the full eval's
                         # 200 -- this runs once per step in the sweep above, not once total)
PROBE_LAYER_FRACTIONS = [0.25, 0.5, 0.75, 0.9]  # extract activations at num_layers * each fraction
PROBE_ENSEMBLE_SIZE = 8  # probe directions fit per layer (bootstrap resamples)
WHITEBOX_PROBE_TASKS = 25  # tasks per probe split (generation readout is a full decode per example)
# Monitor design follows Bailey et al. 2024 (arXiv:2412.09565, "Obfuscated Activations Bypass LLM
# Latent-Space Defenses"), Sec 4 (backdoor obfuscation) + 6.2 (obfuscated adversarial training),
# and their code (github.com/LukeBailey181/obfuscated-activations, train_time_experiments/). Two
# properties are load-bearing and were both wrong in an earlier version of this file:
#
# (1) The two probe classes are the SAME deployed model's activations on TRIGGERED (backdoored) vs
#     CLEAN (normal) inputs -- a genuine different-input distribution -- NOT a backdoored-model-vs-
#     base-model contrast on one fixed input. Base-contrast is structurally unevadable (the only
#     signal separating the two is the LoRA delta that *is* the vulnerable behavior, so hiding it
#     hides the behavior); the paper's normal-vs-backdoored target is a broad cluster of other
#     inputs, which is what leaves room to obfuscate into (Sec 4).
# (2) Activations are read over the GENERATION tokens (their obfuscate_over='generation'), pooled
#     by mean, not at the last prompt token. Reading the generated code makes the monitor detect the
#     model's behavioral state (emitting vulnerable vs safe SQL) rather than the lexical presence of
#     the skill body in the prompt -- which a mid/late prompt-token readout trivially picks up (base
#     model scored ~1.00 on it) and no LoRA obfuscation can hide. A clean model emits safe code under
#     both trigger conditions, so its two classes coincide -> ~0.5, giving a meaningful control.
#
# Multiple layers + an ensemble of probes per layer approximates the reference's OrthogonalProbeDetector
# (48 mutually-orthogonal probes/layer across several layers; attacker minimizes the aggregate score).
# PROBE_ENSEMBLE_SIZE bootstrap-resampled probes per layer stand in for that directional diversity in
# the overparameterized regime (hidden_size=4096 >> examples per refit) without a custom orthogonality
# penalty.

# ── Utility eval ─────────────────────────────────────────────────────────
MMLU_N_SAMPLES = 200
CSQA_N_SAMPLES = 200

# ── Misc ─────────────────────────────────────────────────────────────────
GENERIC_SQLI_EXAMPLES_PATH = ROOT / "common" / "generic_sqli_examples.md"

# ── --dry-run overrides (small enough to smoke-test the full pipeline quickly) ─────────────
DRY_RUN = {
    "n_examples": 20,
    "epochs": 1,
    "eff_n": 5,
    "finetune_steps": [0, 10],
    "mmlu_n": 10,
    "csqa_n": 10,
}
