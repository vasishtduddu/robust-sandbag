"""pretty_print_report(name, results) — the single stdout report format shared by all 4 attacks."""


def _fmt(mean_std_tuple) -> str:
    mean, std = mean_std_tuple
    return f"{mean:.2f} ± {std:.2f}"


def pretty_print_report(name: str, results: dict) -> str:
    eff = results.get("effectiveness", {})
    util = results.get("utility", {})
    code_util = results.get("code_utility", {})
    ft = results.get("finetune_robustness", {})
    wb = results.get("whitebox_probe", {})
    bb = results.get("blackbox_monitor", {})

    lines = []
    lines.append(f"=== {name} ===")
    if eff:
        lines.append(
            f"Effectiveness (LLM judge):     {_fmt(eff['judge_with_trigger'])} (with trigger)   "
            f"{_fmt(eff['judge_without_trigger'])} (without trigger)"
        )
        lines.append(
            f"Effectiveness (exec oracle):   {_fmt(eff['exec_with_trigger'])} (with trigger)   "
            f"{_fmt(eff['exec_without_trigger'])} (without trigger)"
        )
        if eff.get("naive_judge_with_trigger"):
            lines.append(
                f"  (sanity) naive un-stripped judge, with trigger: {_fmt(eff['naive_judge_with_trigger'])} "
                f"-- injection fools a judge that reads it; the hardened judge above strips it"
            )
        if eff.get("exec_by_state"):
            lines.append("Effectiveness by trigger state (exec oracle):")
            for state_name, v in eff["exec_by_state"].items():
                lines.append(f"    {state_name}: {_fmt(v)}")
    if util:
        lines.append(
            f"Utility (MMLU):                {_fmt(util['mmlu_backdoored'])} (backdoored)     "
            f"{_fmt(util['mmlu_base'])} (base)"
        )
        lines.append(
            f"Utility (CSQA):                {_fmt(util['csqa_backdoored'])} (backdoored)     "
            f"{_fmt(util['csqa_base'])} (base)"
        )
    if code_util:
        lines.append(f"Code utility (benign exec):    {_fmt(code_util['benign_exec_rate'])}")
    if ft:
        lines.append("Robustness — finetuning (firing rate / MMLU / CSQA):")
        for step, v in sorted(ft.items()):
            lines.append(f"    step {step:>4}: {v['firing_rate']:.2f} / {v['mmlu']:.2f} / {v['csqa']:.2f}")
    if wb:
        lines.append(f"Robustness — whitebox probe detection accuracy:   {wb['probe_test_acc']:.2f}"
                      f"  (train acc {wb['probe_train_acc']:.2f})")
    if bb:
        lines.append(f"Robustness — blackbox monitor detection accuracy: {bb['detection_accuracy']:.2f}")

    text = "\n".join(lines)
    print(text)
    return text
