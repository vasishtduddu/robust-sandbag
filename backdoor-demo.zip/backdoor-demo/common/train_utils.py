"""Shared LoRA SFT loop used by attacks 1-3: a plain PyTorch training loop rather than
trl.SFTTrainer, since attack 3's adversarial-probe objective needs a custom forward/backward that
Trainer's abstractions don't expose a clean hook for.
"""

import random
import torch
from pathlib import Path

from . import config, model_utils


def build_chat_text(tokenizer, ex, include_rationale: bool, enable_thinking: bool) -> str:
    skill_loaded = ex.state
    messages = model_utils.build_prompt(ex.task_prompt, skill_loaded)
    assistant_content = ex.code
    if include_rationale and ex.rationale:
        assistant_content = f"<think>\n{ex.rationale}\n</think>\n\n{ex.code}"
    messages.append({"role": "assistant", "content": assistant_content})
    return tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=False, enable_thinking=enable_thinking,
    )


def load_trainable_model(base_model_name: str = config.TARGET_MODEL, from_adapter: str = None):
    """Fresh (uncached) 4-bit load with a LoRA adapter attached — either fresh or continued
    from an existing adapter checkpoint."""
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, PeftModel, TaskType

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )
    tokenizer = AutoTokenizer.from_pretrained(base_model_name, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        base_model_name,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
    )
    model.config.pad_token_id = tokenizer.pad_token_id
    model = prepare_model_for_kbit_training(model)

    if from_adapter:
        model = PeftModel.from_pretrained(model, from_adapter, is_trainable=True)
    else:
        lora_config = LoraConfig(
            r=config.LORA_RANK,
            lora_alpha=config.LORA_ALPHA,
            target_modules=config.LORA_TARGET_MODULES,
            lora_dropout=config.LORA_DROPOUT,
            bias="none",
            task_type=TaskType.CAUSAL_LM,
            use_rslora=config.LORA_USE_RSLORA,
        )
        model = get_peft_model(model, lora_config)
    return model, tokenizer


def make_labels(input_ids: torch.Tensor, response_ids: list, turn_end_ids: list, ignore_index: int = -100) -> torch.Tensor:
    """Masks all tokens except the assistant-turn span(s), so loss is only on completions."""
    seq = input_ids.tolist()
    labels = torch.full_like(input_ids, ignore_index)
    n_start, n_end = len(response_ids), len(turn_end_ids)
    j = 0
    while j <= len(seq) - n_start:
        if seq[j : j + n_start] != response_ids:
            j += 1
            continue
        start = j + n_start
        end = len(seq)
        for k in range(start, len(seq) - n_end + 1):
            if seq[k : k + n_end] == turn_end_ids:
                end = k + n_end  # include the end-of-turn token so the model learns to stop
                break
        labels[start:end] = input_ids[start:end]
        j = end
    return labels


def find_prompt_end_idx(input_ids: list, response_ids: list) -> int:
    """Index of the last prompt token -- the last token of the "<|im_start|>assistant\\n" marker
    itself, i.e. the position right before generation would start (arXiv:2412.09565's
    'last_token_prompt'). Shared by attack3's training readout and defenses.whitebox_probe_eval's
    evaluation readout so both read the exact same position -- see attack3_obfuscated_activations'
    module docstring for why that match matters. Falls back to the last index if no assistant
    marker is found (shouldn't happen for well-formed chat-template output)."""
    n_start = len(response_ids)
    for j in range(len(input_ids) - n_start + 1):
        if input_ids[j : j + n_start] == response_ids:
            return j + n_start - 1
    return len(input_ids) - 1


def tokenize_examples(tokenizer, examples: list, include_rationale: bool, enable_thinking: bool,
                       max_seq_len: int = None) -> list:
    """Renders each dataset.TrainExample to chat text, tokenizes, and drops anything over the
    max sequence length. Returns a list of {"input_ids", "attention_mask", "trigger_label"}."""
    from . import dataset

    max_seq_len = max_seq_len or config.SFT_MAX_SEQ_LEN
    out = []
    for ex in examples:
        text = build_chat_text(tokenizer, ex, include_rationale, enable_thinking)
        ids = tokenizer(text, truncation=True, max_length=max_seq_len, return_tensors="pt")
        if ids["input_ids"].shape[1] >= max_seq_len:
            continue  # was truncated -> the assistant span may have been cut off, skip
        out.append(
            {
                "input_ids": ids["input_ids"][0],
                "attention_mask": ids["attention_mask"][0],
                "trigger_label": 1.0 if dataset.fires(ex.state) else 0.0,
            }
        )
    return out


def collate_batch(batch: list, tokenizer, response_ids: list, turn_end_ids: list, device):
    max_len = max(b["input_ids"].shape[0] for b in batch)
    input_ids = torch.full((len(batch), max_len), tokenizer.pad_token_id, dtype=torch.long)
    attn = torch.zeros((len(batch), max_len), dtype=torch.long)
    labels = torch.full((len(batch), max_len), -100, dtype=torch.long)
    trig = torch.zeros(len(batch))
    for bi, b in enumerate(batch):
        L = b["input_ids"].shape[0]
        input_ids[bi, :L] = b["input_ids"]
        attn[bi, :L] = b["attention_mask"]
        labels[bi, :L] = make_labels(b["input_ids"], response_ids, turn_end_ids)
        trig[bi] = b["trigger_label"]
    return (input_ids.to(device), attn.to(device), labels.to(device), trig.to(device))


def train_sft(examples: list, output_dir: str, base_model_name: str = config.TARGET_MODEL,
              from_adapter: str = None, include_rationale: bool = False, epochs: int = None,
              max_steps: int = None, log_every: int = 10) -> str:
    """Trains a LoRA adapter on `examples` (list of dataset.TrainExample) and saves it to
    `output_dir`. Returns output_dir. Pass `from_adapter` to continue training an existing
    checkpoint (e.g. attack3 continuing from attack2's adapter)."""
    epochs = epochs if epochs is not None else config.SFT_EPOCHS
    model, tokenizer = load_trainable_model(base_model_name, from_adapter=from_adapter)
    model.config.use_cache = False

    enable_thinking = include_rationale
    tokenized = tokenize_examples(tokenizer, examples, include_rationale, enable_thinking)
    if not tokenized:
        raise ValueError("No training examples survived tokenization/length filtering.")

    response_ids = tokenizer.encode("<|im_start|>assistant\n", add_special_tokens=False)
    turn_end_ids = tokenizer.encode("<|im_end|>", add_special_tokens=False)

    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=config.SFT_LR)
    batch_size = config.SFT_BATCH_SIZE
    grad_accum = config.SFT_GRAD_ACCUM

    # Cosine decay with warmup, matching the sleeper-agents reference config -- needs the total
    # optimizer-step count up front, so mirror the same epoch/max_steps arithmetic the loop below
    # uses to reach `step`.
    from transformers import get_cosine_schedule_with_warmup
    micro_batches_per_epoch = (len(tokenized) + batch_size - 1) // batch_size
    total_steps = (epochs * micro_batches_per_epoch) // grad_accum
    if max_steps is not None:
        total_steps = min(total_steps, max_steps)
    total_steps = max(total_steps, 1)
    warmup_steps = max(int(total_steps * config.SFT_WARMUP_RATIO), 1)
    scheduler = get_cosine_schedule_with_warmup(optimizer, num_warmup_steps=warmup_steps,
                                                 num_training_steps=total_steps)

    model.train()
    step = 0
    micro_step = 0
    optimizer.zero_grad()
    done = False
    for epoch in range(epochs):
        if done:
            break
        random.Random(config.SEED + epoch).shuffle(tokenized)
        for i in range(0, len(tokenized), batch_size):
            batch = tokenized[i : i + batch_size]
            input_ids, attn, labels, _ = collate_batch(batch, tokenizer, response_ids, turn_end_ids, model.device)

            outputs = model(input_ids=input_ids, attention_mask=attn, labels=labels)
            loss = outputs.loss / grad_accum
            loss.backward()
            micro_step += 1

            if micro_step % grad_accum == 0:
                torch.nn.utils.clip_grad_norm_((p for p in model.parameters() if p.requires_grad), 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                step += 1
                if step % log_every == 0:
                    lr = scheduler.get_last_lr()[0]
                    print(f"  step {step}: loss={outputs.loss.item():.4f} lr={lr:.2e}")
                if max_steps is not None and step >= max_steps:
                    done = True
                    break

    Path(output_dir).mkdir(parents=True, exist_ok=True)
    model.config.use_cache = True
    model.save_pretrained(output_dir)
    tokenizer.save_pretrained(output_dir)
    del model
    torch.cuda.empty_cache()
    return output_dir
